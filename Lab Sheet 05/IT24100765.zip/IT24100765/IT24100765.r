setwd("C://Users//IT24100765//Desktop//IT24100765")
Delivery_Times <- read.table("Exercise - Lab 05.txt",header=TRUE,sep=",")

attach(Delivery_Times)


histogram <- hist(Delivery_Time_.minutes.,main="Histogram for Delivary Time",breaks=seq(20,70,length.out=10),right=FALSE)

#The Distribution of Delivery times is approximately symmetric, with most values between 35 and 45 minutes



cum_freq<- cumsum(histogram$counts)
cum_freq

mids <- round(histogram$mids)
mids

plot(mids,cum_freq,type="o",main=" cumulative frequency polygon",xlab="Delivery Time(minutes)", ylab= "cumulative frequency",col="blue")



